<?php
    include ('menu.html');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <style>
        body
        {
            background-image: url(../images/coffee9.jpg);
            background-repeat: no-repeat;
            background-size: cover;
        }
        .login_bg
        {
            background-image: url(../images/flower2.jpg) ;
            margin: 6px;
            padding-left: 20px;
        }
        .card-body
        {
            background-image: url(../images/coffee10.jpg) ;
            background-repeat: no-repeat;
            image-rendering: crisp-edges;
        }
    </style>
</head>
<body>

<div class="d-flex justify-content-center align-items-center vh-100">
    <form action="login.php" method="post" class="text-center">
        <div class='card mt-5' style='width:400px'>
            <h3 class="login_bg">Employee Registeration </h3>
            <div class='card-body '>
                <input type="text" placeholder="Enter Name " name="name" class="form-control mt-4" required autocomplete="off">
                <input type="tel" pattern=[0-9]{10} placeholder="Enter phone number " name="phone" class="form-control mt-4" required autocomplete="off">
                <input type="number" placeholder="Enter basic " name="basic" class="form-control mt-4" required autocomplete="off">
                <input type="number" placeholder="Enter bonus " name="bonus" class="form-control mt-4" required autocomplete="off">
                <input type="text" placeholder="Enter type " name="type" class="form-control mt-4" required autocomplete="off">
                <input type="submit" value="LOGIN" class='btn btn-info form-control mt-4' >
          
            </div>
      </div>
    </form>
</div>

    
</body>
</html>