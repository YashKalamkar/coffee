<?php

include_once '../shared/connection.php';

$name=$_POST['name'];
$phone=$_POST['phone'];
$basic=$_POST['basic'];
$bonus=$_POST['bonus'];
$type=$_POST['type'];

if(!isset($_POST['name']) && !isset($_POST['phone']) && !isset($_POST['type']))
    {
        echo"<h3>Server Validation is failed !</h3>";
        die;
    }
$sql_status=mysqli_query($conn,"insert into employee(name,phone,type) values('$name','$phone','$type')");
$sql_obj=mysqli_query($conn,"insert into salary(basic,bonus) values('$basic','$bonus');");

if($sql_obj)
{
    header('location:login_fe.php');
}
else
{
    echo"Query failed!";
    die;
}
?>