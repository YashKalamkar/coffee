<?php

    $name=$_POST['name'];
    $price=$_POST['price'];
    $description=$_POST['description'];

    if(!isset($_FILES['pdt_image']) && !isset($_POST['name']) && !isset($_POST['price']))
    {
        echo"<h3>Server Validation is failed !</h3>";
        die;
    }
    $img=$_FILES['pdt_image'];
    
    $error=$img['error'];
    if($error==1)
    {
        echo"<h3>Upload Failed try again </h3>";
        die;
    }
    $tmp_name=$img['tmp_name'];
    
    date_default_timezone_set('Asia/Kolkata');
    $date_str=date('d_M_Y_H_i_s').'.jpg';

    move_uploaded_file($tmp_name,"../images1/$date_str");

    $conn=new mysqli('localhost','root','','coffee_cafe');

    $cmd="insert into menu(name,price,description,imname) values('$name',$price,'$description','$date_str')";
    $sql_status=mysqli_query($conn,$cmd);

    if($sql_status)
    {
        header('location:upload_fe.php');
    }
    else
    {
        echo"<h3>Error in SQL syntax</h3>";
    }

   



?>