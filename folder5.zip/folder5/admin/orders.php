
<html>
<head>

</head>
<body>
    <table>
    <?php
        include_once('../shared/connection.php');
    ?>
        <tr>
            <
    </table>
</body>
</html>
