<?php
    include('menu.html');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
   
    <style>
        body
        {
            background-image: url(../images/flower2.jpg);
            background-repeat: no-repeat;
            background-size: cover;
        }
        
    </style>
</head>
<body>
    <div class="d-flex justify-content-center align-items-center vh-100">
        
        <form action="upload.php" enctype="multipart/form-data" method="post" class="w-25 bg-warning p-4 text-center m-4">
            
            <h3>Upload product </h3>

            <input  name="name" type="text" placeholder="Product name" class="form-control mt-4" autocomplete="off" required>
            <input  name="price" type="number" placeholder="Product price" class="form-control mt-4" autocomplete="off" required>

            <textarea required name="description" placeholder="Product description" cols="30" rows="3" class="mt-4 form-control" autocomplete="off"></textarea>
            
            <input name="pdt_image" type="file" accept="image/*" class="form-control mt-4" autocomplete="off" required>
            <input   type="submit" value="UPLOAD" class="form-control mt-4 btn btn-outline-primary">
            
        </form>


    </div>
</body>
</html>