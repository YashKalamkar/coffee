<?php

if(!isset($_GET['m_id']))
{
    echo "Missing Fields";
    die;
}

$name=$_POST['name'];
$price=$_POST['price'];
$description=$_POST['description'];

$m_id=$_GET['m_id'];

$img=$_FILES['pdt_image'];
    
    $error=$img['error'];
    if($error==1)
    {
        echo"<h3>Upload Failed try again </h3>";
        die;
    }
    $tmp_name=$img['tmp_name'];
    
    date_default_timezone_set('Asia/Kolkata');
    $date_str=date('d_M_Y_H_i_s').'.jpg';

    move_uploaded_file($tmp_name,"../images1/$date_str");

    include_once '../shared/connection.php';

$sql_obj=mysqli_query($conn,"UPDATE menu 
                  SET name = '$name' , price = '$price' , description = '$description' ,imname = '$date_str' 
                WHERE m_id=$m_id");

if($sql_obj)
{
    header('location:viewmenu.php');
}
else
{
    echo"Query failed !";
    die;
}
?>