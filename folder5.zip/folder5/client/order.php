<!DOCTYPE html>
<html lang="en"> 
<head>
    <style>
        body
        {
            background-image:url(../images/coffee6.jpg); 
            background-repeat:no-repeat;
            background-size:cover;
        }
        .card
        {
            box-shadow: 20px 20px 40px black;
        }
       
    </style>
</head>
<body>
<?php
include('menu.html');
?>    

<div class="d-flex justify-content-start align-items-center">
<?php

$conn=new mysqli('localhost','root','','coffee_cafe');

if(!isset($_GET['m_id']))
{
    echo "Missing Fields";
    die;
}

$m_id=$_GET['m_id'];

$sql_obj=mysqli_query($conn,"select * from menu where m_id=$m_id");

$total_count=mysqli_num_rows($sql_obj);

for($i=0;$i<$total_count;$i++)
    {

        $row=mysqli_fetch_assoc($sql_obj);

        $m_id=$row['m_id'];
        $name=$row['name'];
        $price=$row['price'];
        $description=$row['description'];
        $imname=$row['imname'];

    echo"<div class='d-flex justify-content-start'>";  

        echo"<div class='card m-5' style='width:300px '>
                <img src='../images1/$imname' class='card-img-top' alt='Card image'>
                <div class='card-body'>
                    <h4 class='card-title'>$name <span class='text-danger'>$price Rs </span></h4>
                    <p class='card-text'>$description</p>
                        
          
                </div>
            </div>";
    }
    
    echo "</div>";
    
        





?>
</body>
</html>




</div>

