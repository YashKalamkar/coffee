<?php

include_once '../shared/connection.php';

$cname=$_POST['cname'];
$cphone=$_POST['cphone'];
$cpassword=$_POST['cpassword'];

if(!isset($_POST['cname']) && !isset($_POST['cphone']))
    {
        echo"<h3>Server Validation is failed !</h3>";
        die;
    }
$sql_status=mysqli_query($conn,"insert into customer(cname,cphone,cpassword) values('$cname','$cphone','$cpassword')");

if($sql_status) 
{
    header('location:coffeeshop_fe.php');
}
else
{
    echo"Query failed!";
    die;
}
?>