<?php
    

    $conn=new mysqli('localhost','root','','coffee_cafe');

    $sql_obj=mysqli_query($conn,"select * from orders where oid=(select MAX(oid) FROM orders);");

    $row=mysqli_fetch_assoc($sql_obj);

        $oid=$row['oid'];
        $name=$row['name'];
        $price=$row['price'];
        $quantity=$row['quantity'];
        $total_price=$row['total_price'];
?>

<html>
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <style>
        body
        {
            /* background-color: rgb(174, 234, 235); */
            
        }
        .backtomenu
        {
            text-decoration:none;
            color:white;
            weight:400;
        }
        /* #background
        {
            background-image:url('../images/coffee.jpg');
            background-repeat:no-repeat;
            background-size:cover;
        } */
        #back__btn{
            border-radius:0px;
            padding:px;
        }

        .card-body img{
            width:300px;
            height:150px;
            border-radius:20px;
        }
        #back-image
        {
            background-image:url('../images/flower2.jpg');
            background-repeat:no-repeat;
            background-size:cover;

        }      
        .card
        {
            border:none;
        }  
        
        button a
        {
            text-decoration:none;
            weight:400;
            color:white;
        }
        .icons a
        {
            font-size:30px;
            padding:15px;
            
           
        }
        .icons
        {
            margin-top:15px;
            padding-bottom:30px;
        }
        .card
        {
            /* box-shadow: insert 0 -3em 3em rgba(0,0,0,0.1), 0 0 0 2px rgb(255,255,255), 0.3em 0.3em 1em rgba(0,0,0,0.3); */
            box-shadow: 0 0 100px silver;
        }
        .btn 
        {
            border-radius:0px !important;
        }
        #btn {
            font-weight:bold;
            
        }
        #btn:hover
        {
            color:white;
            
        }
        #view
        {
            position:absolute;
            right:50px;
            top:30px;
            
            
        }
        #view:hover 
        {
            letter-spacing:2px;
            right:40px;
            
        }
        
    </style>
</head>
<body>
    
    <div class="container cont__">
        <div class="row" style="margin-top:140px;">
            <div class="col-lg-12">
                <div class="card text-center" style="padding:20px" >
                <button type="button" class="btn btn-primary bold" id="view" data-toggle="modal" data-target="#myModal">VIEW ORDER</button>
            <?php
            echo"
                
            <div class='modal fade' id='myModal' role='dialog'>
            <div class='modal-dialog'>
            
                
                <div class='modal-content'>
                <div class='modal-header'>

                    <h4 class='modal-title '></h4>
                </div>
                <div class='modal-body'>
                <p><b>Your order no : $oid </b></p>
                <p><b>You ordered : $name </b></p>
                <p><b>total quantity : $quantity</b></p>
                <p><b>Your Total amount : $total_price (taxes include)</b></p>
                </div>
                <div class='modal-footer'>
                    <button type='button' class='btn btn-outline-warning' data-dismiss='modal'>Close</button>
                </div>
                </div>
                
            </div>
            </div>
            ";
            ?>

                    <div class='card-body' id="back-image">
                        <img src="../images/thanks2.jpg">
                        <h3 class='card-title'>Your order is on the way ! <i class="fa fa-motorcycle" aria-hidden="true"></i></h3>
                        <div class="d-flex justify-content-around mt-5">
                            <button class="p-2 btn btn-primary" ><a href="viewmenu.php" id="btn" class="text-decoration-none"><i class="fa fa-arrow-left mr-2"  aria-hidden="true"></i> BACK TO MENU</a></button> 
                            <button class="p-2 btn btn-danger"><a href="coffeeshop_fe.php" id="btn" class="text-decoration-none">VISIT AGAIN <i class="fa fa-external-link ml-2"  aria-hidden="true"></i></a></button>
                            <!-- <a><i class="fa fa-twitter-square" aria-hidden="true"></i></a><a><i class="fa fa-whatsapp" aria-hidden="true"></i></a><a><i class="fa fa-instagram" aria-hidden="true"></i></a>-->
                            
                        </div>
                        <div class="icons">
                        <a href="#"> <i class="fa fa-twitter " aria-hidden="true"></i></a><a href="#" ><i class="fa fa-whatsapp " style="color:#3eb345" aria-hidden="true"></i></a><a><i class="fa fa-instagram " style="color:#E1306C" aria-hidden="true"></i></a>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</body>
</html>

