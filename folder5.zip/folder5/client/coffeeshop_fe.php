<?php
    include 'menu.html';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <style>
        body
        {
            width: 100%;
            height: 100vh;
            margin: 0;
            padding: 0;
            background-image: url(../images/coffee4.jpg);
            background-size: cover;
               
        }
        /* #name 
        {    
            padding:40px;
            color:white;
            background-color:rgb(72, 70, 70);
            width:fit-content;
            font-size: xx-large;
            box-shadow:0 0  100px black;
        }  */

    </style>
</head>
<body>
    <!-- <div class="d-flex justify-content-center align-items-center " style="margin-top:200px;">
        <a href="viewmenu.php" class="text-decoration-none "><h2 id="name">VINTAGE COFFEECAFE<h2></a>
    </div> -->
</body>
</html>