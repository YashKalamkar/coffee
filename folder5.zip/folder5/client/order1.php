<html>
<head>
    <style>
        #quantity
        {
            position:absolute;
            top:65px;
            left:400px;
            
        }
        #background 
        {
            background-image:url(../images/flower.jpg);
            box-shadow: 20px 20px 50px black;
            background-repeat:no-repeat;
            background-size:cover;
        }
    </style>
</head>
<body>

<?php
include('order.php');
$conn=new mysqli('localhost','root','','coffee_cafe');
if(!isset($_GET['m_id']))
{
    echo "Missing Fields";
    die;
}
$m_id=$_GET['m_id'];

echo"

<div class='d-flex ' id='quantity'>

    
    <div class=' card d-flex mt-5 justify-content-start align-items-center' id='background' style='width:1000px '>
        
    <form action='billing.php?m_id=$m_id' method='post' class='text-center'>
            <input required type='number' placeholder='Enter quantity' name=quantity class='form-control mt-4' >
            <input type='submit' value='ORDEEEEEER' class='form-control mt-4 mb-4 btn btn-primary'>

        </form>
        
</a>
    </div>
</div>
";
?>
</body>
</html>



