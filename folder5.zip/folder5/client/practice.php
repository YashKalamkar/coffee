<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>
    
</body>
</html>

<?php

$conn=new mysqli('localhost','root','','coffee_cafe');

$sql_obj=mysqli_query($conn,"select * from orders where oid=(select MAX(oid) FROM orders);");

$row=mysqli_fetch_assoc($sql_obj);

        $oid=$row['oid'];
        $name=$row['name'];
        $price=$row['price'];
        $quantity=$row['quantity'];
        $total_price=$row['total_price'];
    //Model
    echo"
   
    <div class='modal fade' id='myModal' role='dialog'>
      <div class='modal-dialog'>
      
        
        <div class='modal-content'>
          <div class='modal-header'>
            <button type='button' class='close' data-dismiss='modal'>&times;</button>
            <h4 class='modal-title'>Your order is successfully placed..!</h4>
          </div>
          <div class='modal-body'>
            <p>Your order no : $oid </p>
            <p>Your You ordered : $name </p>
            <p>Your quantity : $quantity</p>
            <p>Your Total amount : $total_price </p>
          </div>
          <div class='modal-footer'>
            <button type='button' class='btn btn-primary' data-dismiss='modal'>Close</button>
          </div>
        </div>
        
      </div>
    </div>

    ";
?>