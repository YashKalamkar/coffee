<?php

$conn=new mysqli('localhost','root','','coffee_cafe');

$m_id=$_GET['m_id'];
$quantity=$_POST['quantity'];
if(!isset($_GET['m_id']))
{
    echo "Missing Fields";
    die;
}

$sql_obj=mysqli_query($conn,"select * from menu where m_id=$m_id");

$row=mysqli_fetch_assoc($sql_obj);
$name=$row['name'];
$price=$row['price'];
$total_price=$price * $quantity;

$sql_obj=mysqli_query($conn,"insert into orders(name,price,quantity,total_price) values('$name','$price','$quantity','$total_price') ");
if($sql_obj)
{
    header('location:orderlist.php');
}
else
{
    echo"Query failed !";
}
?>