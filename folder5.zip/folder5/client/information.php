<!--<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <style>
        body
        {
            background-image: url(../images/coffee.jpg);
            background-repeat: no-repeat;
            background-size: cover;
        }
        .heading
        {
            background-image:url(../images/coffee3.jpg);
            color:black;
            text-align: center;
            text-transform: uppercase;
            
        }
        .card-body
        {
            background-image: url(../images/coffee3.jpg) ;
            background-repeat: no-repeat;
            image-rendering: crisp-edges;
            color:black;
            padding:4px;
        }
      
        .card-text
        {
            padding:4px;
        }
        .card-title
        {
            padding:4px;
        }
    </style>
</head>
<body>
    
</body>
</html>  -->
<?php
include('menu.html');
$conn=new mysqli('localhost','root','','coffee_cafe');
    
$sql_obj=mysqli_query($conn,'select * FROM coffeeshop');

$total_count=mysqli_num_rows($sql_obj);

//echo"<div class='d-flex flex-wrap justify-content-center align-items-center '>";

// for($i=0;$i<$total_count;$i++)
// {
    $row=mysqli_fetch_assoc($sql_obj); 
    

    $phone=$row['phone'];
    $location=$row['location'];
    $timing=$row['timing'];
    $rating=$row['rating'];
    echo"
    <div class=' d-flex justify-content-center align-items-center ' id='box' style='margin-top:150px;'>
            <div class='card' style='width:'>
                <div class='card-body'>
                <div class='d-flex '>
                    <img   width='40px' height='40px' src='../images/coffee11.jpg'>
                    <h5 class='card-title mt-3 text-center pl-2'>VINTAGE COFFEESHOP</h5>
                </div>
                    <h5 class='card-subtitle mb-2 text-muted text-center'>Phone Number: $phone</h5>
                    <p class='card-text'>Our Location :$location</p>
                    <div class='d-flex justify-content-around'> 
                        <b><p class='card-text'>Timing :$timing</p></b>
                        <b><p class='card-text'>Rating :$rating</p></b>
                    </div>
                    <div class='icons'>
                        <a href='#'><i class='fa fa-instagram ' style='color:#E1306C' aria-hidden='true'></i></a>
                        <a href='#' ><i class='fa fa-whatsapp ' style='color:#3eb345' aria-hidden='true'></i></a>                    </div>
                </div>
            </div>
        </div>
    ";
?>
<html>
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
        body
        {
            background-image:url(../images/coffee12.jpg);
            background-size:cover;
            background-repeat:no-repeat;
        }
        .card-title 
        {
            font-weight:bold;
        }
        .icons a
        {
            font-size:30px;
            padding:55px;
            justify-content: space-evenly;
           
        }
        .icons
        {
            margin-top:15px;
            padding-bottom:15px;
            justify-content: space-evenly;

        }
        .card
        {
            box-shadow: 0 0 50px black;
        }
        .card-title 
        {
            color:darkgreen; 
            margin-bottom:25px;
            
        }
        .card-subtitle
        {
            color:black !important;
        }
        .card-text 
        {
            color:black !important;
            weight:700;
        }
        .circle 
        {
            width:400px;
            height:400px;
            border-radius:200px;
            position:absolute;
            top:310px;
            right:100px;
            border:none;
            box-shadow:inset 0 0 60px #FBBC95;
        }
        .image 
        {
            width:350px;
            height:350px;
            border-radius:200px;
            position:absolute;
            top:25px;
            right:25px;
            
        }
    </style>
</head>
<body>
    
        <button class="circle">
            <img src="../images/coffee14.jpg" class="image">
        </button>
        
</body>
</html>