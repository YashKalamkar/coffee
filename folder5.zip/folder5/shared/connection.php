<?php

$conn=new mysqli('localhost','root','','coffee_cafe');

if($conn->connect_error)
{
    echo"<h2>Connection Failed !</h2>";
}

?>
